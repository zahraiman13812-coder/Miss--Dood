import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export const runtime = "nodejs";
export async function GET() {
 try { await db().query("SELECT 1"); return NextResponse.json({ status: "ok" }, { headers: { "Cache-Control": "no-store" } }); }
 catch { return NextResponse.json({status:"unavailable"}, {status:503,headers:{"Cache-Control":"no-store"}}); }
}
